import json
import boto3
from decimal import Decimal

def lambda_handler(event, context):
    try:
        print("=== GET BUILDING FUNCTION ===")
        
        # Extract building_id
        building_id = None
        
        if 'queryStringParameters' in event and event['queryStringParameters']:
            if isinstance(event['queryStringParameters'], dict):
                building_id = event['queryStringParameters'].get('building_id')
        
        print(f"Building ID: {building_id}")
        
        if not building_id:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true'
                },
                'body': json.dumps({'message': 'building_id is required'})
            }
        
        # Connect to DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Buildings-prod')
        
        # Get item from DynamoDB
        response = table.get_item(Key={'building_id': building_id})
        
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true'
                },
                'body': json.dumps({'message': 'Building not found'})
            }
        
        # Convert Decimal to JSON serializable
        def convert_decimal(obj):
            if isinstance(obj, Decimal):
                return int(obj) if obj % 1 == 0 else float(obj)
            elif isinstance(obj, dict):
                return {k: convert_decimal(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_decimal(i) for i in obj]
            else:
                return obj
        
        item = response['Item']
        converted_item = convert_decimal(item)
        
        print(f"Successfully returning building: {converted_item.get('building_name')}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true'
            },
            'body': json.dumps(converted_item)
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        print(traceback.format_exc())
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true'
            },
            'body': json.dumps({'message': 'Internal server error', 'error': str(e)})
        }
